import { tiktok } from "d-scrape/utils/scrape.js";

(async () => {
    const url = "https://vt.tiktok.com/ZSYUmj2EQ/";
    if (!url.includes('tiktok.com')) return 'Invalid URL';
    const data = await tiktok(url);
    console.log(data);
})();