import PonyoAI from "../resources/script/ponyoai.js";
import { readFileSync } from 'fs';


const session = JSON.parse(readFileSync("./resources/database/session-ponyoai.json"));

