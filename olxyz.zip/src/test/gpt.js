import { GPT4 } from "../resources/script/chatgpt.js";

GPT4(`Mengapa penggunaan bahasa daerah dianggap penting dalam menjaga keberagaman budaya di Indonesia ....
*
Karena memperkuat dominasi bahasa nasional
Karena membatasi pemahaman budaya lokal
Karena mempromosikan homogenitas budaya
Karena memperkaya keberagaman bahasa dan budaya
Karena menekankan superioritas budaya tertentu

jawabannya apa?`).then(console.log);