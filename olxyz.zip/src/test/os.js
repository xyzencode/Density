import os from "os";

(async () => {
    console.log(os.platform())
})();
