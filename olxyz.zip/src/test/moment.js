import moment from 'moment-timezone';

const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY');
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss');
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss');
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss');

(async () => {
    console.log(`Hari ini adalah ${hariini}`)
    console.log(`Waktu Indonesia Bagian Barat: ${wib}`)
    console.log(`Waktu Indonesia Bagian Tengah: ${wita}`)
    console.log(`Waktu Indonesia Bagian Timur: ${wit}`)
})();
