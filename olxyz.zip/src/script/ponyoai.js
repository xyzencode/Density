// Code By Muhammad Adriansyah - Zayden
// Please Don't Change the Credit Or Delete This Comment
// Thanks For Using My Code

// Powered By apigratis.site
'use client';

// import fetch from 'node-fetch';
import { readFileSync, writeFileSync } from 'fs';

const session = JSON.parse(readFileSync("./resources/database/session-ponyoai.json"));

/*
    PonyoAI
    @param message: string
    @param chat_id: string
    @return Promise
*/
async function PonyoAI(message, chat_id = "") {
    return new Promise(async (resolve, reject) => {
        await fetch("https://api.apigratis.site/cai/send_message", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                external_id: "2FSEywr9HrnEIPV0HEvSUC0OARyE5s-2XOJs489p3q4",
                message,
                chat_id,
            })
        }).then((response) => {
            resolve(response.json());
        }).catch((error) => {
            reject(error);
        });
    });
}

// Session Handler
const getSession = async (users) => {
    const a = session.find((session) => session.users === users);
    return a ? a : null;
}

const addSession = async (users, chat_id) => {
    session.push({ users, chat_id });
    writeFileSync("./resources/database/session-ponyoai.json", JSON.stringify(session, null, 2));
}

/*
    PonyoAIHandler
    @param message: string
    @param number: string
    @return Promise
*/
export default async function PonyoAIHandler(message, number) {
    return new Promise(async (resolve, reject) => {
        const session = await getSession(number);
        if (session) {
            PonyoAI(message, session.chat_id)
                .then((response) => {
                    resolve(response);
                })
                .catch((error) => {
                    reject(error);
                });
        } else {
            PonyoAI(message)
                .then((response) => {
                    const chat_id = response.result.chat_id;
                    addSession(number, chat_id);
                    resolve(response);
                })
                .catch((error) => {
                    reject(error);
                });
        }
    });
}